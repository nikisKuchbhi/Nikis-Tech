<?php $__env->startSection('title'); ?> <?php echo e($aboutsetting->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($aboutsetting->meta_description); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/front/magnific.min.css')); ?>" type="text/css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
       <h1 class="breadcrumb-title"><?php echo e($aboutsetting->meta_title); ?></h1>
       <ul class="page-list">
            <li class="item-home"><a class="bread-link" href="<?php echo e(route('home')); ?>" title="Home"><?php echo e($aboutsetting->breadcrumbs_anchor); ?></a></li>
            <li class="separator separator-home"></li>
            <li class="item-current"><?php echo e($aboutsetting->meta_title); ?></li>
        </ul>
   </div>

   <div class="about-us">
       <div class="container">
           <div class="row align-items-center">
               <div class="col-md-5">
       
                   <div class="simpleParallax-video">
                        <div class="simpleParallax">
                            <img width="500" height="665" src="/public/img/loading-blog.gif" class="lazy thumparallax img-fluid" data-src="<?php echo e($aboutsetting->about_image); ?>" alt="about-image">
                        </div>
                        <a class="popup-vimeo-video" href="<?php echo e($aboutsetting->about_ytlink); ?>">
                            <i class="far fa-play-circle"></i>
                        </a>
                    </div>
               </div>
               <div class="col-md-7">


                    <h4 class="about-heading1-home"><?php echo e($aboutsetting->about_subtitle); ?></h4>
                    <h3 class="about-heading2-home"><?php echo e($aboutsetting->about_title); ?></h3>

                    <?php echo $aboutsetting->about_description; ?>


                    <a href="<?php echo e($aboutsetting->about_buttonlink); ?>" target="_self" class="btn btn-style1"><span><?php echo e($aboutsetting->about_buttontext); ?></span></a>
       
                   
               </div>
           </div>
       </div>
   </div>

   <div class="members-section">
        <div class="container">
            <h3 class="members-heading1"><?php echo e($aboutsetting->member_title_section); ?></h3>
        

            <div class="row">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-4">
                      <div class="niva-team">
                          <div class="thumbnail"> 
                              <img width="350" height="350" class="lazy img-fluid" src="/public/img/loading-blog.gif" data-src="<?php echo e($member->photo ? '/public/images/media/' . $member->photo->file : '/public/img/200x200.png'); ?>" alt="team-niva">
                          </div>
                          <div class="content">
                              <h5 class="title"><?php echo e($member->name); ?></h5>
                              <p class="position"><?php echo e($member->position); ?></p>
                          </div>
                          <ul class="social-icon">
                              <li><a target="_blank" rel="noopener" href="<?php echo e($member->facebook); ?>"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                              <li><a target="_blank" rel="noopener" href="<?php echo e($member->linkedin); ?>"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                              <li><a target="_blank" rel="noopener" href="<?php echo e($member->twitter); ?>"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                          </ul>
                      </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

    <div class="testimonial-section">

        <div class="testimonial-section-slider owl-carousel">

            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <blockquote class="testimonial-slide">
                <div class="section_title"><?php echo e($testimonial->subtitle); ?></div>
                <span class="testimonial_slider_title"><?php echo e($testimonial->title); ?></span>
                    <div class="testimonial-area">
                        <div class="testimonial-layoutArea">
                           <p><?php echo e($testimonial->description); ?></p>
                        </div>
                    </div>
                <div class="testimonials_slider_name"> <?php echo e($testimonial->name); ?><span> - <?php echo e($testimonial->position); ?></span></div>
            </blockquote>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>


    <div class="clients-section">
        <div class="container">
            
            <div class="clients-slider owl-carousel">
                  <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="clients-slide">
                      <a title="<?php echo e($client->company_name); ?>" target="_blank" href="<?php echo e($client->company_link); ?>"><img class="client_image owl-lazy" data-src="<?php echo e($client->photo ? '/public/images/media/' . $client->photo->file : '/public/img/200x200.png'); ?>" alt="<?php echo e($client->company_name); ?>"></a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/front/magnific.min.js')); ?>" defer></script>
<script>
( function ( $ ) {
    'use strict';
    $( document ).ready( function () {
        $(".popup-vimeo-video").magnificPopup({
          type:"iframe",
          removalDelay: 160,
          preloader: false,
          fixedContentPos: false
        });
    })
} ( jQuery ) )
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/about.blade.php ENDPATH**/ ?>