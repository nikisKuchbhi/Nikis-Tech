<?php $__env->startSection('content'); ?>
    <h1>Edit</h1>

    <div class="col-md-9">
        <form method="post" action="<?php echo e(route('admin.users.edit', $user->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">name</label>
                <input type="text"
                       name="name"
                       class="form-control"
                       id="name"
                       aria-describedby=""
                       placeholder="Enter name"
                       value="<?php echo e($user->name); ?>"

                >
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>

        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>