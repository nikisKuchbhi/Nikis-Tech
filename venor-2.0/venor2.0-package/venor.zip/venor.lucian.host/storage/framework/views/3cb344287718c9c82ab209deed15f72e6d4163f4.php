<?php $__env->startSection('title'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
       <h1 class="breadcrumb-title"><?php echo e(clean( trans('niva-backend.you_searched_for') , array('Attr.EnableID' => true))); ?> <?php echo e($term); ?></h1>
   </div>

   

 

   <div class="portfolio-section-filters">
      <div class="container">
        <div class="row">

            <div class="col-md-12">
                  <div class="projects projects-page row">

                  	<?php if(count($project_list)): ?>
	                      <?php $__currentLoopData = $project_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                      <div class="project col-md-4" data-filter="<?php echo e($project->project_category->name); ?>">
	                        <div class="project-inner">
	                            <div class="project-thumbnail">
	                              <a href="<?php echo e(URL::to('/')); ?>/project/<?php echo e($project->slug); ?>" title=""><img width="400" height="250" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->photo ? '/public/images/media/' . $project->photo->file : '/public/img/200x200.png'); ?>" class="lazy img-fluid" alt="<?php echo e($project->title); ?>"></a>
	                              </div>
	                              <h4 class="entry-details-title"> <a href="<?php echo e(URL::to('/')); ?>/project/<?php echo e($project->slug); ?>"><?php echo e($project->title); ?></a></h4>
	                              <h5 class="project-category"><?php echo e($project->project_category->name); ?></h5>
	                        </div>
	                      </div>
	                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                <?php else: ?> 
					    <div>
					        <h4 class="no-results"><?php echo e(clean( trans('niva-backend.no_results') , array('Attr.EnableID' => true))); ?></h4>
					    </div>
					<?php endif; ?>     

                  </div>
            </div>

        </div>
      </div>
   </div>





<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
		$(document).ready(function () {
			jQuery('.header__search__venor input').val("<?php echo e($term); ?>") //blade / php dynamic functionality
		});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/venor.lucian.host/resources/views/search.blade.php ENDPATH**/ ?>