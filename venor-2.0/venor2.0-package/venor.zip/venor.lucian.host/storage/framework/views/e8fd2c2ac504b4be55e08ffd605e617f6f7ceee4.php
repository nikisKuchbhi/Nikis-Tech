Inquiry from: <?php echo e($name); ?>

<p> Email: <?php echo e($email); ?> </p>
<p> Subject: <?php echo e($subject); ?> </p>
<p> Budget: <?php echo e($budget); ?> </p>
<p> Message: <?php echo e($comment); ?> </p><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/email.blade.php ENDPATH**/ ?>