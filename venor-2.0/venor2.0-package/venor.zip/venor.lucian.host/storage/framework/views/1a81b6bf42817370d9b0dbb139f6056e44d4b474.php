<?php $__env->startSection('content'); ?>
    <h1><?php echo trans('home.Create'); ?> <?php echo trans('home.User'); ?></h1>
    <?php echo Form::open(['method' => 'POST', 'action' => 'AdminUsersController@store', 'files' => true] ); ?>

    <div class="row">
    <div class="col-md-6">   
    <div class="form-group">
        <?php echo Form::label('name', Lang::get('home.Name_and_Surname')); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('email', 'Email:'); ?>

        <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('phone', Lang::get('home.Phone')); ?>

        <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('city', Lang::get('home.City')); ?>

        <?php echo Form::text('city', null, ['class' => 'form-control']); ?>

    </div>
    </div>
    <div class="col-md-6">   
    <div class="form-group">
        <?php echo Form::label('address', Lang::get('home.Address')); ?>

        <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('role_id', Lang::get('home.Role')); ?>

        <?php echo Form::select('role_id', [''=> 'Choose role'] + $roles, null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('is_active', Lang::get('home.Status')); ?>

        <?php echo Form::select('is_active',array('1' => 'Active', '0' => 'Offline'), 0, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('photo_id', Lang::get('home.Photo')); ?>

        <?php echo Form::file('photo_id', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('password', Lang::get('home.Password')); ?>

        <?php echo Form::password('password', ['class' => 'form-control']); ?>

    </div>
    <?php ($create_user = Lang::get('home.Create') . ' ' . Lang::get('home.User') ); ?>
    <div class="form-group">
        <?php echo Form::submit($create_user, ['class' => 'btn btn-primary']); ?>

    </div>
    </div>
    </div>
 
    <?php echo $__env->make('includes.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/admin/users/create.blade.php ENDPATH**/ ?>