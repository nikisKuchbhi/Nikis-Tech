<?php


return [



    'all' => 'Todos',
    'sort_by' => 'Ordenar por',
    'call_help' => 'Pedir ajuda:',
    'mail_us' => 'Envie para nós:',
    'our_address' => 'Nosso endereço:',
 
    'no_results' => 'Sem resultados',
    'search_text' => 'Pesquisar tema wordpress',
    'you_searched_for' => 'Você pesquisou por:',
];