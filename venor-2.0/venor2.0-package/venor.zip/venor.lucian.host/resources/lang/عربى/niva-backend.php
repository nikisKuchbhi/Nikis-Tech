<?php


return [



    'all' => 'الجميع',
    'sort_by' => 'ترتيب حسب',
    'call_help' => 'طلب المساعدة:',
    'mail_us' => 'أرسل لنا:',
    'our_address' => 'عنواننا:',
    
    'no_results' => 'لا نتائج',
    'search_text' => 'جرب موضوع ووردبريس',
    'you_searched_for' => 'لقد بحثت عن:',

];