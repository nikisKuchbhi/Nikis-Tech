<?php
$options = array();
$options[] = array(
	'id'          => '_bunch_layout_settings',
	'types'       => array('post', 'page', 'product', 'bunch_services', 'bunch_projects' ),
	'title'       => __('Layout Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
					
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', BUNCH_NAME),
						'description' => __('Choose the layout for blog pages', BUNCH_NAME),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png',
							),
							
						),
					),
					
					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', BUNCH_NAME),
						'default' => '',
						'items' => bunch_get_sidebars(true)	
					),
				),
);
$options[] = array(
	'id'          => '_bunch_header_settings',
	'types'       => array('page', 'post', 'bunch_services', 'bunch_projects' ),
	'title'       => __('Header Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
                    array(
        				'type' => 'select',
        				'name' => 'header_styles',
        				'label' => __('Header Styles', BUNCH_NAME),
        				'default' => 'header_v1',
        				'items' => array(
        					array(
        						'value' => 'header_v1',
        						'label' => __('style 1', BUNCH_NAME),
        					),
        					array(
        						'value' => 'header_v2',
        						'label' => __('Style 2', BUNCH_NAME),
        					),
        					array(
        						'value' => 'header_v3',
        						'label' => __('style 3', BUNCH_NAME),
        					),
							array(
        						'value' => 'header_v4',
        						'label' => __('style 4', BUNCH_NAME),
        					),
        					array(
        						'value' => 'header_v5',
        						'label' => __('Style 5', BUNCH_NAME),
        					),
        					array(
        						'value' => 'header_v6',
        						'label' => __('style 6', BUNCH_NAME),
        					),
							array(
        						'value' => 'header_v7',
        						'label' => __('style 7', BUNCH_NAME),
        					),
        				),
						'default' => 'header_v7'
        			),
					array(
						'type' => 'textbox',
						'name' => 'header_title',
						'label' => __('Header Title', BUNCH_NAME),
						'description' => __('Enter the Header title', BUNCH_NAME),
					),
					array(
						'type' => 'textbox',
						'name' => 'header_text',
						'label' => __('Header Text', BUNCH_NAME),
						'description' => __('Enter the Header Text', BUNCH_NAME),
					),
					array(
						'type' => 'upload',
						'name' => 'header_img',
						'label' => __('Header image', BUNCH_NAME),
						'default' => '',
					),
					array(
						'type' => 'toggle',
						'name' => 'breadcrumb',
						'label' => __('Enable / disable Header Banner', BUNCH_NAME),
						'description' => __('Enable / disable Header area for KC template', BUNCH_NAME),
					),
					
				),
);

$options[] =  array(
	'id'          => _WSH()->set_meta_key('post'),
	'types'       => array('post'),
	'title'       => __('Post Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(		
					
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'gallery_imgs',
					'title'     => __( 'Gallery images', BUNCH_NAME ),
					'fields'    => array(
						array(
							'type' => 'upload',
							'name' => 'gallery_image',
							'label' => __( 'Gallery Image', BUNCH_NAME ),
							'description' => __( 'Choose the Gallery images', BUNCH_NAME ),
						),
					),
				),
				array(
					'type' => 'textarea',
					'name' => 'video',
					'label' => __('Video Embed Code', BUNCH_NAME),
					'default' => '',
					'description' => __('If post format is video then this embed code will be used in content', BUNCH_NAME)
				),
				array(
					'type' => 'textarea',
					'name' => 'quote_description',
					'label' => __('Quote Description', BUNCH_NAME),
					'default' => '',
					'description' => __('If post format is quote then the content in this textarea will be displayed', BUNCH_NAME)
				),
				array(
					'type' => 'textbox',
					'name' => 'author_name',
					'label' => __('Author name', BUNCH_NAME),
					'default' => '',
					'description' => __('Author name', BUNCH_NAME)
				),
			),
);
/* Page options */
/** Slides Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_slide'),
	'types'       => array('bunch_slide'),
	'title'       => __('Slides Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
	
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_slide_text',
					'title'     => __('Slide Content', BUNCH_NAME),
					'fields'    => array(
						
						array(
							'type' => 'textarea',
							'name' => 'slide_text',
							'label' => __('Slide Text', BUNCH_NAME),
							'default' => '',
							
						),
					),
				),
			),
		);

/** Services Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_services'),
	'types'       => array( 'bunch_services' ),
	'title'       => __('Services Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
				array(
					'type' => 'fontawesome',
					'name' => 'fontawesome',
					'label' => __('Service Icon', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_projects_image',
					'title'     => __('Services Images', BUNCH_NAME),
					'fields'    => array(
						array(
							'type' => 'upload',
							'name' => 'projects_image',
							'label' => __('Services Images', BUNCH_NAME),
							'default' => '',
						),
					),
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_services_accordion',
					'title'     => __('Our Accordion', BUNCH_NAME),
					'fields'    => array(
						array(
							'type' => 'textbox',
							'name' => 'acc_title',
							'label' => __('Title', BUNCH_NAME),
							'default' => '',
						),
						array(
							'type' => 'textarea',
							'name' => 'acc_text',
							'label' => __('Text', BUNCH_NAME),
							'default' => '',
						),
					),
				),
		),
);

/** Projets Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_projects'),
	'types'       => array('bunch_projects'),
	'title'       => __('Projects Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'select',
					'name' => 'extra_width',
					'label' => __('Image Size adjustment for shortcode', BUNCH_NAME),
					'default' => 'normal_width',
					'items' => array(
								array(
									'value' => 'normal_width',
									'label' => __('Normal Width and Height', BUNCH_NAME),
								),
								array(
									'value' => 'midum_width',
									'label' => __('Midum Width and Height', BUNCH_NAME),
								),
								array(
									'value' => 'extra_width',
									'label' => __('Extra Width and Height', BUNCH_NAME),
								),
								
						),
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_projects_image',
					'title'     => __('Projects Images', BUNCH_NAME),
					'fields'    => array(
						array(
							'type' => 'upload',
							'name' => 'projects_image',
							'label' => __('Project Images', BUNCH_NAME),
							'default' => '',
						),
					),
				),
				array(
					'type' => 'textbox',
					'name' => 'sub_title',
					'label' => __('Sub Title', BUNCH_NAME),
					'default' => 'Project Information',
				),
				array(
					'type' => 'textarea',
					'name' => 'description',
					'label' => __('Project Description', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_project_info',
					'title'     => __('Project Information', BUNCH_NAME),
					'fields'    => array(
						
						array(
							'type' => 'textbox',
							'name' => 'info_title',
							'label' => __('Title', BUNCH_NAME),
							'default' => '',
						),
						array(
							'type' => 'textbox',
							'name' => 'info_description',
							'label' => __('Description', BUNCH_NAME),
							'default' => '',
						),
					),
				),
				array(
					'type' => 'textbox',
					'name' => 'con_upper_title',
					'label' => __('Sub Title', BUNCH_NAME),
					'default' => 'Quick Contact',
				),
				array(
					'type' => 'textbox',
					'name' => 'con_title',
					'label' => __('Title', BUNCH_NAME),
					'default' => 'GET SOLUTION',
				),
				array(
					'type' => 'textarea',
					'name' => 'con_text',
					'label' => __('Title', BUNCH_NAME),
					'default' => 'Contact us at the Interior office nearest to you or submit a business inquiry online.',
				),
				array(
					'type' => 'textbox',
					'name' => 'con_btn_title',
					'label' => __('Button Title', BUNCH_NAME),
					'default' => 'Contact',
				),
				array(
					'type' => 'textbox',
					'name' => 'con_btn_link',
					'label' => __('Button Link', BUNCH_NAME),
					'default' => '#',
				),
		),
);

/** Team Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_team'),
	'types'       => array('bunch_team'),
	'title'       => __('Team Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_team_social',
					'title'     => __('Social Profile', BUNCH_NAME),
					'fields'    => array(
						
						array(
							'type' => 'fontawesome',
							'name' => 'social_icon',
							'label' => __('Social Icon', BUNCH_NAME),
							'default' => '',
						),
						array(
							'type' => 'textbox',
							'name' => 'social_link',
							'label' => __('Link', BUNCH_NAME),
							'default' => '',
							
						),
					),
				),
				array(
					'type' => 'textbox',
					'name' => 'sub_title',
					'label' => __('Skill Title', BUNCH_NAME),
					'default' => 'Skills',
				),
				array(
					'type'      => 'group',
					'repeating' => true,
					'length'    => 1,
					'name'      => 'bunch_team_summary',
					'title'     => __('Summary Area', BUNCH_NAME),
					'fields'    => array(
						array(
							'type' => 'textbox',
							'name' => 'title1',
							'label' => __('Title', BUNCH_NAME),
							'default' => '',
						),
						array(
							'type' => 'textbox',
							'name' => 'fill_bar_value',
							'label' => __('Fill Bar Value', BUNCH_NAME),
							'default' => '',
						),
					),
				),
		),
);

/** Testimonial Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_testimonials'),
	'types'       => array('bunch_testimonials'),
	'title'       => __('Testimonials Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'select',
					'name' => 'testimonial_rating',
					'label' => __('Client Rating', BUNCH_NAME),
					'description' => __('Choose the Client Rating', BUNCH_NAME),
					'items' => array( 
						array(
							'value'=>'1',
							'label'=>'1'
						), 
						array(
							'value'=>'2',
							'label'=>'2'
						), 
						array(
							'value'=>'3',
							'label'=>'3'
						), 
						array(
							'value'=>'4',
							'label'=>'4'
						), 
						array(
							'value'=>'5',
							'label'=>'5'
						), 
					),
				'default' => '5'
				),
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('Read More Link', BUNCH_NAME),
					'default' => '',
				),
		),
);
 
 return $options; 