<?php
/**
 * Kingcomposer array
 *
 * @package Student WP
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

$orderby = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order By", BUNCH_NAME),
				"name"			=>	"sort",
				'options'		=>	array('date'=>esc_html__('Date', BUNCH_NAME),'title'=>esc_html__('Title', BUNCH_NAME) ,'name'=>esc_html__('Name', BUNCH_NAME) ,'author'=>esc_html__('Author', BUNCH_NAME),'comment_count' =>esc_html__('Comment Count', BUNCH_NAME),'random' =>esc_html__('Random', BUNCH_NAME) ),
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$order = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order", BUNCH_NAME),
				"name"			=>	"order",
				'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$number = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Number', BUNCH_NAME ),
				"name"			=>	"num",
				"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME )
			);
$text_limit = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Text Limit', BUNCH_NAME ),
				"name"			=>	"text_limit",
				"description"	=>	esc_html__('Enter text limit of posts to Show.', BUNCH_NAME )
			);
$title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"title",
				"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
			);
$sub_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Sub-Title', BUNCH_NAME ),
				"name"			=>	"sub_title",
				"description"	=>	esc_html__('Enter section subtitle.', BUNCH_NAME )
			);
$text  = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"text",
				"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
			);
$btn_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Title', BUNCH_NAME ),
				"name"			=>	"btn_title",
				"description"	=>	esc_html__('Enter section Button title.', BUNCH_NAME )
			);
$btn_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Link', BUNCH_NAME ),
				"name"			=>	"btn_link",
				"description"	=>	esc_html__('Enter section Button Link.', BUNCH_NAME )
			);
$bg_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
				"name"			=>	"bg_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Background image Url.', BUNCH_NAME )
			);

$options = array();


// Revslider Start.
$options['bunch_revslider']	=	array(
					'name' => esc_html__('Revslider', BUNCH_NAME),
					'base' => 'bunch_revslider',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show  Revolution slider.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'dropdown',
									'label' => esc_html__('Choose Slider', BUNCH_NAME ),
									'name' => 'slider_slug',
									'options' => bunch_get_rev_slider( 0 ),
									'description' => esc_html__('Choose Slider', BUNCH_NAME )
								),
							),
						);
//Home Slider V1
$options['bunch_home_slider_v1']	=	array(
					'name' => esc_html__('Home Slider V1', BUNCH_NAME),
					'base' => 'bunch_home_slider_v1',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Home Slider V1.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'group',
									'label' => esc_html__( 'Slide Information', BUNCH_NAME ),
									'name' => 'slide_info',
									'description' => esc_html__( 'Enter The Slide Information.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Slide Background Image', BUNCH_NAME ),
											"name"			=>	"bg_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Background Image.', BUNCH_NAME )
										),
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										$text,
										$btn_title,
										$btn_link,
									),
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Phone Number', BUNCH_NAME ),
									'name' => 'phone_no',
									'description' => esc_html__( 'Enter The Phone Number.', BUNCH_NAME ),
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Email Address', BUNCH_NAME ),
									'name' => 'email_address',
									'description' => esc_html__( 'Enter The Email Address.', BUNCH_NAME ),
								),
							),
						);
//About Us
$options['bunch_about_us']	=	array(
					'name' => esc_html__('About Us', BUNCH_NAME),
					'base' => 'bunch_about_us',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The About Us.', BUNCH_NAME),
					'params' => array(
								$bg_img,
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Alphabet Image', BUNCH_NAME ),
									"name"			=>	"alphabet_img",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Upload The Alphabet Image.', BUNCH_NAME )
								),
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('About Image', BUNCH_NAME ),
									"name"			=>	"about_img",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Upload The About Image.', BUNCH_NAME )
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Sub Title', BUNCH_NAME ),
									'name' => 'sub_title',
									'description' => esc_html__( 'Enter The Sub Title.', BUNCH_NAME ),
								),
								$text,
								$btn_title,
								$btn_link,
							),
						);

//Our Specialization
$options['bunch_our_specialization']	=	array(
					'name' => esc_html__('Our Specialization', BUNCH_NAME),
					'base' => 'bunch_our_specialization',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Specialization.', BUNCH_NAME),
					'params' => array(
								$bg_img,
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								$text_limit,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
							),
						);
//Funfacts V2
$options['bunch_funfacts_v2']	=	array(
                    'name' => esc_html__('Funfacts V2', BUNCH_NAME),
                    'base' => 'bunch_funfacts_v2',
                    'class' => '',
                    'category' => esc_html__('Contra', BUNCH_NAME),
                    'icon' => 'fa-briefcase' ,
                    'description' => esc_html__('Show The Funfacts V2.', BUNCH_NAME),
                    'params' => array(
                                $bg_img,
                                array(
                                    'type' => 'group',
                                    'label' => esc_html__('Our Funfact', BUNCH_NAME),
                                    'name' => 'funfact',
                                    'description' => esc_html__('Enter The Our Funfact.', BUNCH_NAME),
                                    'params' => array(
                                        array(
                                            'type' => 'text',
                                            'label' => esc_html__('Counter Start', BUNCH_NAME),
                                            'name' => 'counter_start',
                                            'description' => esc_html__('Enter The Counter Start.', BUNCH_NAME),
                                        ),
                                        array(
                                            'type' => 'text',
                                            'label' => esc_html__('Counter Stop', BUNCH_NAME),
                                            'name' => 'counter_stop',
                                            'description' => esc_html__('Enter The Counter Stop.', BUNCH_NAME),
                                        ),
                                        array(
                                            'type' => 'text',
                                            'label' => esc_html__('Title', BUNCH_NAME),
                                            'name' => 'title',
                                            'description' => esc_html__('Enter The Title.', BUNCH_NAME),
                                        ),
                                        array(
                                            'type' => 'text',
                                            'label' => esc_html__('AlphaBet Value', BUNCH_NAME),
                                            'name' => 'alphabet_value',
                                            'description' => esc_html__('Enter The AlphaBet Value.', BUNCH_NAME),
                                        ),
                                    ),
                                ),
                            ),
                        );
//Our Projects
$options['bunch_our_projects']	=	array(
					'name' => esc_html__('Our Projects', BUNCH_NAME),
					'base' => 'bunch_our_projects',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Projects.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'projects_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$orderby,
								$order,
							),
						);
//Our Team
$options['bunch_our_team']	=	array(
					'name' => esc_html__('Our Team', BUNCH_NAME),
					'base' => 'bunch_our_team',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Team.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Upper Title', BUNCH_NAME ),
									'name' => 'upper_title',
									'description' => esc_html__( 'Enter The Upper Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'team_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
								array(
									"type"			=>	"select",
									"label"			=>	esc_html__("Team Style", BUNCH_NAME),
									"name"			=>	"style_two",
									'options'		=>	(array('one'=>esc_html__('Style One', BUNCH_NAME),'two'=>esc_html__('Style Two', BUNCH_NAME) ) ),			
									"description"	=>	esc_html__("Choose Team Style.", BUNCH_NAME)
								),
							),
						);
//Our Testimonials
$options['bunch_our_testimonials']	=	array(
					'name' => esc_html__('Our Testimonials', BUNCH_NAME),
					'base' => 'bunch_our_testimonials',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Testimonials.', BUNCH_NAME),
					'params' => array(
								esc_html__( 'General', BUNCH_NAME ) => array(
									array(
										'type' => 'text',
										'label' => esc_html__( 'Background Title', BUNCH_NAME ),
										'name' => 'bg_title',
										'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
									),
									$title,
									$text,
								),
								esc_html__( 'Our Testimonials', BUNCH_NAME ) => array(
									$bg_img,
									$number,
									$text_limit,
									array(
										"type" => "dropdown",
										"label" => __( 'Category', BUNCH_NAME),
										"name" => "cat",
										"options" =>  bunch_get_categories(array( 'taxonomy' => 'testimonials_category'), true),
										"description" => __( 'Choose Category.', BUNCH_NAME)
									),
									$order,
									$orderby,
								),
							),
						);
//News & Articals
$options['bunch_news_and_articals']	=	array(
					'name' => esc_html__('News & Articals', BUNCH_NAME),
					'base' => 'bunch_news_and_articals',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The News & Articals.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$orderby,
								$order,
							),
						);
//Our Partners
$options['bunch_our_partners']	=	array(
					'name' => esc_html__('Our Partners', BUNCH_NAME),
					'base' => 'bunch_our_partners',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Partners.', BUNCH_NAME),
					'params' => array(
								$bg_img,
								array(
									'type' => 'group',
									'label' => esc_html__( 'Our Sponsors', BUNCH_NAME ),
									'name' => 'sponsors',
									'description' => esc_html__( 'Enter The Our Sponsors.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Sponsors Image', BUNCH_NAME ),
											"name"			=>	"image",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Choose Sponsors Image Url.', BUNCH_NAME )
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'External Link', BUNCH_NAME ),
											'name' => 'link',
											'description' => esc_html__( 'Enter The External Link.', BUNCH_NAME ),
										),
									),
								),
								array(
									"type"			=>	"select",
									"label"			=>	esc_html__("Our Partner Style", BUNCH_NAME),
									"name"			=>	"style_two",
									'options'		=>	(array('one'=>esc_html__('Style One', BUNCH_NAME),'two'=>esc_html__('Style Two', BUNCH_NAME),'three'=>esc_html__('Style Three', BUNCH_NAME) ) ),			
									"description"	=>	esc_html__("Choose Our Partner Style.", BUNCH_NAME)
								),
							),
						);
//Home Slider V2
$options['bunch_home_slider_v2']	=	array(
					'name' => esc_html__('Home Slider V2', BUNCH_NAME),
					'base' => 'bunch_home_slider_v2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Home Slider V2.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'group',
									'label' => esc_html__( 'Slide Information', BUNCH_NAME ),
									'name' => 'slide_info',
									'description' => esc_html__( 'Enter The Slide Information.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Slide Background Image', BUNCH_NAME ),
											"name"			=>	"bg_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Background Image.', BUNCH_NAME )
										),
										$sub_title,
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Video Link', BUNCH_NAME ),
											'name' => 'video_link',
											'description' => esc_html__( 'Enter The Video Link.', BUNCH_NAME ),
										),
									),
								),
							),
						);

//About Us Style Two
$options['bunch_about_us2']	=	array(
					'name' => esc_html__('About Us Two', BUNCH_NAME),
					'base' => 'bunch_about_us2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The About Us Two.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Upper Title', BUNCH_NAME ),
									'name' => 'upper_title',
									'description' => esc_html__( 'Enter The Upper Title.', BUNCH_NAME ),
								),
								$title,
								array(
									'type' => 'text',
									'label' => esc_html__( 'Heading Title', BUNCH_NAME ),
									'name' => 'heading_title',
									'description' => esc_html__( 'Enter The Heading Title.', BUNCH_NAME ),
								),
								$text,
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Next Description', BUNCH_NAME ),
									"name"			=>	"text1",
									"description"	=>	esc_html__('Enter The Next Description.', BUNCH_NAME )
								),
								$btn_title,
								$btn_link,
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Company Image', BUNCH_NAME ),
									"name"			=>	"image",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Choose Company image Url.', BUNCH_NAME )
								),
							),
						);

//Our Specialization V2
$options['bunch_our_specialization_v2']	=	array(
					'name' => esc_html__('Our Specialization V2', BUNCH_NAME),
					'base' => 'bunch_our_specialization_v2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Specialization V2.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
							),
						);
//Funfacts And Features
$options['bunch_funfacts_and_features']	=	array(
					'name' => esc_html__('Funfacts And Features', BUNCH_NAME),
					'base' => 'bunch_funfacts_and_features',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Funfacts And Features.', BUNCH_NAME),
					'params' => array(
					            esc_html__( 'Our Funfacts', BUNCH_NAME ) => array(
									array(
										"type"			=>	"attach_image_url",
										"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
										"name"			=>	"bg_img",
										'admin_label' 	=> 	false,
										"description"	=>	esc_html__('Upload Background Image.', BUNCH_NAME )
									),
									array(
										'type' => 'group',
										'label' => esc_html__( 'Our Funfact', BUNCH_NAME ),
										'name' => 'funfact',
										'description' => esc_html__( 'Enter Our Funfact.', BUNCH_NAME ),
										'params' => array(
											array(
												'type' => 'text',
												'label' => esc_html__( 'Counter Start', BUNCH_NAME ),
												'name' => 'counter_start',
												'description' => esc_html__( 'Enter The Counter Start.', BUNCH_NAME ),
											),
											array(
												'type' => 'text',
												'label' => esc_html__( 'Counter Stop', BUNCH_NAME ),
												'name' => 'counter_stop',
												'description' => esc_html__( 'Enter The Counter Stop.', BUNCH_NAME ),
											),
											array(
												'type' => 'text',
												'label' => esc_html__( 'Alphabet Letter', BUNCH_NAME ),
												'name' => 'alphabet_letter',
												'description' => esc_html__( 'Enter The Alphabet Letter.', BUNCH_NAME ),
											),
											array(
												'type' => 'textarea',
												'label' => esc_html__( 'Title', BUNCH_NAME ),
												'name' => 'title',
												'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
											),
										),
									),
									array(
										"type"			=>	"checkbox",
										"label"			=>	esc_html__('Style Two', BUNCH_NAME ),
										"name"			=>	"style_two",
										'options' => array(
											'option_1' => 'Style Two',
										),
										"description"	=>	esc_html__('Choose whether you want to show The Different Spacing.', BUNCH_NAME  )
									),
								),
								esc_html__( 'Feature Services', BUNCH_NAME ) => array(
									$number,
									$text_limit,
									array(
										"type" => "dropdown",
										"label" => __( 'Category', BUNCH_NAME),
										"name" => "cat",
										"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
										"description" => __( 'Choose Category.', BUNCH_NAME)
									),
									$order,
									$orderby,
								),
							),
						);
//Our Best Projects
$options['bunch_our_best_projects']	=	array(
					'name' => esc_html__('Our Best Projects', BUNCH_NAME),
					'base' => 'bunch_our_best_projects',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Best Projects.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$btn_title,
								$btn_link,
								$number,
								$text_limit,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'projects_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$orderby,
								$order,
							),
						);
//Special Offer
$options['bunch_special_offer']	=	array(
					'name' => esc_html__('Special Offer', BUNCH_NAME),
					'base' => 'bunch_special_offer',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Special Offer.', BUNCH_NAME),
					'params' => array(
								$bg_img,
								$sub_title,
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Discount Value', BUNCH_NAME ),
									'name' => 'discount_value',
									'description' => esc_html__( 'Enter The Discount Value.', BUNCH_NAME ),
								),
								$text,
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Contact Form', BUNCH_NAME ),
									'name' => 'contact_form',
									'description' => esc_html__( 'Enter The Contact Form.', BUNCH_NAME ),
								),
							),
						);
//Funfacts
$options['bunch_funfacts']	=	array(
					'name' => esc_html__('Our Funfacts', BUNCH_NAME),
					'base' => 'bunch_funfacts',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Funfacts.', BUNCH_NAME),
					'params' => array(
					            array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
									"name"			=>	"bg_img",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Upload Background Image.', BUNCH_NAME )
								),
								array(
									'type' => 'group',
									'label' => esc_html__( 'Our Funfact', BUNCH_NAME ),
									'name' => 'funfact',
									'description' => esc_html__( 'Enter Our Funfact.', BUNCH_NAME ),
									'params' => array(
										array(
											'type' => 'text',
											'label' => esc_html__( 'Counter Start', BUNCH_NAME ),
											'name' => 'counter_start',
											'description' => esc_html__( 'Enter The Counter Start.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Counter Stop', BUNCH_NAME ),
											'name' => 'counter_stop',
											'description' => esc_html__( 'Enter The Counter Stop.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Alphabet Letter', BUNCH_NAME ),
											'name' => 'alphabet_letter',
											'description' => esc_html__( 'Enter The Alphabet Letter.', BUNCH_NAME ),
										),
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
									),
								),
							),
						);
//Our Products
$options['bunch_our_products']	=	array(
					'name' => esc_html__('Our Products', BUNCH_NAME),
					'base' => 'bunch_our_products',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Products.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$sub_title,
								$text,
								$btn_title,
								$btn_link,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'product_cat'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$orderby,
								$order,
							),
						);
//News & Articals
$options['bunch_news_and_articals']	=	array(
					'name' => esc_html__('News & Articals', BUNCH_NAME),
					'base' => 'bunch_news_and_articals',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The News & Articals.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$orderby,
								$order,
							),
						);
//News & Articals V2
$options['bunch_news_and_articals_v2']	=	array(
					'name' => esc_html__('News & Articals V2', BUNCH_NAME),
					'base' => 'bunch_news_and_articals_v2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The News & Articals V2.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$orderby,
								$order,
							),
						);
//Home Slider V3
$options['bunch_home_slider_v3']	=	array(
					'name' => esc_html__('Home Slider V3', BUNCH_NAME),
					'base' => 'bunch_home_slider_v3',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Home Slider V3.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'group',
									'label' => esc_html__( 'Slide Information', BUNCH_NAME ),
									'name' => 'slide_info',
									'description' => esc_html__( 'Enter The Slide Information.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Slide Background Image', BUNCH_NAME ),
											"name"			=>	"bg_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Background Image.', BUNCH_NAME )
										),
										$sub_title,
										array(
											'type' => 'text',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										$text,
										$btn_title,
										$btn_link,
									),
								),
								array(
									'type' => 'group',
									'label' => esc_html__( 'Social Icons', BUNCH_NAME ),
									'name' => 'social_icons',
									'description' => esc_html__( 'Enter The Social Icons.', BUNCH_NAME ),
									'params' => array(
										array(
											'type' => 'icon_picker',
											'label' => esc_html__( 'Icon', BUNCH_NAME ),
											'name' => 'icons',
											'description' => esc_html__( 'Enter The Icon.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'social_title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'External Link', BUNCH_NAME ),
											'name' => 'social_link',
											'description' => esc_html__( 'Enter The External Link.', BUNCH_NAME ),
										),
									),
								),
							),
						);
//Our Specialization V3
$options['bunch_our_specialization_v3']	=	array(
					'name' => esc_html__('Our Specialization V3', BUNCH_NAME),
					'base' => 'bunch_our_specialization_v3',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Specialization V3.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								$sub_title,
								$text,
								$btn_title,
								$btn_link,
								array(
									'type' => 'group',
									'label' => esc_html__( 'Architectural Design Image', BUNCH_NAME ),
									'name' => 'architectural_design',
									'description' => esc_html__( 'Enter The Architectural Design Image.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Thumb Image', BUNCH_NAME ),
											"name"			=>	"thumb_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Thumb Image url.', BUNCH_NAME )
										),
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Main Image', BUNCH_NAME ),
											"name"			=>	"image",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Main Image.', BUNCH_NAME )
										),
									),
								),
								array(
									"type"			=>	"select",
									"label"			=>	esc_html__("Our Specialization Style", BUNCH_NAME),
									"name"			=>	"style_two",
									'options'		=>	(array('one'=>esc_html__('Style One', BUNCH_NAME),'two'=>esc_html__('Style Two', BUNCH_NAME) ) ),			
									"description"	=>	esc_html__("Choose Our Specialization Style.", BUNCH_NAME)
								),
							),
						);
//How We Work
$options['bunch_how_we_work']	=	array(
					'name' => esc_html__('How We Work', BUNCH_NAME),
					'base' => 'bunch_how_we_work',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The How We Work.', BUNCH_NAME),
					'params' => array(
					            $bg_img,
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								$number,
								$text_limit,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
							),
						);
//Our Testimonials V2
$options['bunch_our_testimonials_v2']	=	array(
					'name' => esc_html__('Our Testimonials V2', BUNCH_NAME),
					'base' => 'bunch_our_testimonials_v2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Testimonials V2.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								$number,
								$text_limit,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'testimonials_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
							),
						);
//Campaign Video
$options['bunch_campaign_video']	=	array(
					'name' => esc_html__('Campaign Video', BUNCH_NAME),
					'base' => 'bunch_campaign_video',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Campaign Video.', BUNCH_NAME),
					'params' => array(
					            $bg_img,
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								$sub_title,
								$text,
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Video Image', BUNCH_NAME ),
									"name"			=>	"video_img",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Upload Video Image url.', BUNCH_NAME )
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Video Link', BUNCH_NAME ),
									'name' => 'video_link',
									'description' => esc_html__( 'Enter The Video Link.', BUNCH_NAME ),
								),
								array(
									"type"			=>	"select",
									"label"			=>	esc_html__("Campaign Video Style", BUNCH_NAME),
									"name"			=>	"style_two",
									'options'		=>	(array('one'=>esc_html__('Style One', BUNCH_NAME),'two'=>esc_html__('Style Two', BUNCH_NAME) ) ),			
									"description"	=>	esc_html__("Choose Campaign Video Style.", BUNCH_NAME)
								),
							),
						);
//Our Faqs
$options['bunch_our_faqs']	=	array(
					'name' => esc_html__('Our Faqs', BUNCH_NAME),
					'base' => 'bunch_our_faqs',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Our Faqs.', BUNCH_NAME),
					'params' => array(
					            array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Feature Image', BUNCH_NAME ),
									"name"			=>	"feature_img",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Upload Feature Image url.', BUNCH_NAME )
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'group',
									'label' => esc_html__( 'Our Accordion', BUNCH_NAME ),
									'name' => 'accordion',
									'description' => esc_html__( 'Enter The Our Accordion.', BUNCH_NAME ),
									'params' => array(
										array(
											'type' => 'text',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'acc_title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Text', BUNCH_NAME ),
											'name' => 'acc_text',
											'description' => esc_html__( 'Enter The Text.', BUNCH_NAME ),
										),
									),
								),
							),
						);
//Mobile App
$options['bunch_mobile_app']	=	array(
					'name' => esc_html__('Mobile App', BUNCH_NAME),
					'base' => 'bunch_mobile_app',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Mobile App.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'textarea',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Mobile Image', BUNCH_NAME ),
									"name"			=>	"mobile_image",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Upload Mobile Image url.', BUNCH_NAME )
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Sub Title', BUNCH_NAME ),
									'name' => 'sub_title',
									'description' => esc_html__( 'Enter The Sub Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Text', BUNCH_NAME ),
									'name' => 'text',
									'description' => esc_html__( 'Enter The Text.', BUNCH_NAME ),
								),
							),
						);
//News & Articals V3
$options['bunch_news_and_articals_v3']	=	array(
					'name' => esc_html__('News & Articals V3', BUNCH_NAME),
					'base' => 'bunch_news_and_articals_v3',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The News & Articals V3.', BUNCH_NAME),
					'params' => array(
								esc_html__( 'General', BUNCH_NAME ) => array(
									array(
										'type' => 'text',
										'label' => esc_html__( 'Background Title', BUNCH_NAME ),
										'name' => 'bg_title',
										'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
									),
									array(
										'type' => 'text',
										'label' => esc_html__( 'Title', BUNCH_NAME ),
										'name' => 'title',
										'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
									),
								),
								esc_html__( 'Blog Left', BUNCH_NAME ) => array(
									$text_limit,
									$number,
									array(
										"type" => "dropdown",
										"label" => __( 'Category', BUNCH_NAME),
										"name" => "cat",
										"options" =>  bunch_get_categories(array( 'taxonomy' => 'category'), true),
										"description" => __( 'Choose Category.', BUNCH_NAME)
									),
									$orderby,
									$order,
								),
								esc_html__( 'Blog Right', BUNCH_NAME ) => array(
									array(
										"type"			=>	"text",
										"label"			=>	esc_html__('Number', BUNCH_NAME ),
										"name"			=>	"num1",
										"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME )
									),
									array(
										"type"			=>	"text",
										"label"			=>	esc_html__('Number of Text To Show', BUNCH_NAME ),
										"name"			=>	"text_limit1",
										"description"	=>	esc_html__('Enter Number of Text to Show.', BUNCH_NAME )
									),
									array(
										"type" => "dropdown",
										"label" => __('Category', BUNCH_NAME),
										"name" => "cat1",
										"options" =>  bunch_get_categories(array('taxonomy' => 'category'), true),
										"description" => __('Choose Category.', BUNCH_NAME)
									),
									array(
										"type"			=>	"select",
										"label"			=>	esc_html__("Order By", BUNCH_NAME),
										"name"			=>	"sort1",
										'options'		=>	array('date'=>esc_html__('Date', BUNCH_NAME),'title'=>esc_html__('Title', BUNCH_NAME) ,'name'=>esc_html__('Name', BUNCH_NAME) ,'author'=>esc_html__('Author', BUNCH_NAME),'comment_count' =>esc_html__('Comment Count', BUNCH_NAME),'random' =>esc_html__('Random', BUNCH_NAME) ),
										"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
									),
									array(
										"type"			=>	"select",
										"label"			=>	esc_html__("Order", BUNCH_NAME),
										"name"			=>	"order1",
										'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
										"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
									),
								),
							),
						);
//Contact Us
$options['bunch_contact_us']	=	array(
					'name' => esc_html__('Contact Us', BUNCH_NAME),
					'base' => 'bunch_contact_us',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Contact Us.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								array(
									'type' => 'text',
									'label' => esc_html__( 'Title', BUNCH_NAME ),
									'name' => 'title',
									'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
								),
								$sub_title,
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Address', BUNCH_NAME ),
									"name"			=>	"address",
									"description"	=>	esc_html__('Enter The Address.', BUNCH_NAME )
								),
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Phone Number', BUNCH_NAME ),
									"name"			=>	"phone_no",
									"description"	=>	esc_html__('Enter The Phone Number.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Email Address', BUNCH_NAME ),
									"name"			=>	"email",
									"description"	=>	esc_html__('Enter The Email Address.', BUNCH_NAME )
								),
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
									"name"			=>	"contact_form",
									"description"	=>	esc_html__('Enter The Contact Form.', BUNCH_NAME )
								),
							),
						);
//Home Slider V4
$options['bunch_home_slider_v4']	=	array(
					'name' => esc_html__('Home Slider V4', BUNCH_NAME),
					'base' => 'bunch_home_slider_v4',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Home Slider V4.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'group',
									'label' => esc_html__( 'Slide Information', BUNCH_NAME ),
									'name' => 'slide_info',
									'description' => esc_html__( 'Enter The Slide Information.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Slide Background Image', BUNCH_NAME ),
											"name"			=>	"bg_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Background Image.', BUNCH_NAME )
										),
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										$text,
										$btn_title,
										$btn_link,
									),
								),
							),
						);
//Home Slider V5
$options['bunch_home_slider_v5']	=	array(
					'name' => esc_html__('Home Slider V5', BUNCH_NAME),
					'base' => 'bunch_home_slider_v5',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Home Slider V5.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'group',
									'label' => esc_html__( 'Slide Information', BUNCH_NAME ),
									'name' => 'slide_info',
									'description' => esc_html__( 'Enter The Slide Information.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Slide Background Image', BUNCH_NAME ),
											"name"			=>	"bg_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Background Image.', BUNCH_NAME )
										),
										$sub_title,
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Video Link', BUNCH_NAME ),
											'name' => 'video_link',
											'description' => esc_html__( 'Enter The Video Link.', BUNCH_NAME ),
										),
									),
								),
								array(
									'type' => 'group',
									'label' => esc_html__( 'Social Icons', BUNCH_NAME ),
									'name' => 'social_icons',
									'description' => esc_html__( 'Enter The Social Icons.', BUNCH_NAME ),
									'params' => array(
										array(
											'type' => 'icon_picker',
											'label' => esc_html__( 'Icon', BUNCH_NAME ),
											'name' => 'icons',
											'description' => esc_html__( 'Enter The Icon.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'External Link', BUNCH_NAME ),
											'name' => 'social_link',
											'description' => esc_html__( 'Enter The External Link.', BUNCH_NAME ),
										),
									),
								),
							),
						);
//Home Slider V6
$options['bunch_home_slider_v6']	=	array(
					'name' => esc_html__('Home Slider V6', BUNCH_NAME),
					'base' => 'bunch_home_slider_v6',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Home Slider V6.', BUNCH_NAME),
					'params' => array(
					            array(
									'type' => 'group',
									'label' => esc_html__( 'Slide Information', BUNCH_NAME ),
									'name' => 'slide_info',
									'description' => esc_html__( 'Enter The Slide Information.', BUNCH_NAME ),
									'params' => array(
										array(
											"type"			=>	"attach_image_url",
											"label"			=>	esc_html__('Slide Background Image', BUNCH_NAME ),
											"name"			=>	"bg_img",
											'admin_label' 	=> 	false,
											"description"	=>	esc_html__('Upload Slide Background Image.', BUNCH_NAME )
										),
										array(
											'type' => 'textarea',
											'label' => esc_html__( 'Upper Box Title', BUNCH_NAME ),
											'name' => 'title1',
											'description' => esc_html__( 'Enter The Upper Box Title To Show.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Upper Box Button Title', BUNCH_NAME ),
											'name' => 'btn_title1',
											'description' => esc_html__( 'Enter The Upper Box Button Title To Show.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Upper Box Button Link', BUNCH_NAME ),
											'name' => 'btn_link1',
											'description' => esc_html__( 'Enter The Upper Box Button Link To Show.', BUNCH_NAME ),
										),
										$sub_title,
										array(
											'type' => 'text',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										$text,
										$btn_title,
										$btn_link,
									),
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Phone Number', BUNCH_NAME ),
									'name' => 'phone_no',
									'description' => esc_html__( 'Enter The Phone Number.', BUNCH_NAME ),
								),
								array(
									'type' => 'textarea',
									'label' => esc_html__( 'Email', BUNCH_NAME ),
									'name' => 'email',
									'description' => esc_html__( 'Enter The Email.', BUNCH_NAME ),
								),
								array(
									'type' => 'group',
									'label' => esc_html__( 'Social Icons', BUNCH_NAME ),
									'name' => 'social_icons',
									'description' => esc_html__( 'Enter The Social Icons.', BUNCH_NAME ),
									'params' => array(
										array(
											'type' => 'icon_picker',
											'label' => esc_html__( 'Icon', BUNCH_NAME ),
											'name' => 'icons',
											'description' => esc_html__( 'Enter The Icon.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'Title', BUNCH_NAME ),
											'name' => 'social_title',
											'description' => esc_html__( 'Enter The Title.', BUNCH_NAME ),
										),
										array(
											'type' => 'text',
											'label' => esc_html__( 'External Link', BUNCH_NAME ),
											'name' => 'social_link',
											'description' => esc_html__( 'Enter The External Link.', BUNCH_NAME ),
										),
									),
								),
							),
						);
//Faq Form
$options['bunch_faq_form']	=	array(
					'name' => esc_html__('Faq Form', BUNCH_NAME),
					'base' => 'bunch_faq_form',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show The Faq Form.', BUNCH_NAME),
					'params' => array(
								array(
									'type' => 'text',
									'label' => esc_html__( 'Background Title', BUNCH_NAME ),
									'name' => 'bg_title',
									'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
								),
								$title,
								array(
									"type"			=>	"textarea",
									"label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
									"name"			=>	"contact_form",
									"description"	=>	esc_html__('Enter section Contact Form.', BUNCH_NAME )
								),
							),
						);
//Our Team V2
$options['bunch_our_team_v2']	=	array(
					'name' => esc_html__('Our Team V2', BUNCH_NAME),
					'base' => 'bunch_our_team_v2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Team V2.', BUNCH_NAME),
					'params' => array(
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'team_category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
							),
						);
//Our Projects V2
$options['bunch_our_projects_v2']	=	array(
					'name' => esc_html__('Our Projects V2', BUNCH_NAME),
					'base' => 'bunch_our_projects_v2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Projects V2.', BUNCH_NAME),
					'params' => array(
								$number,
								array(
								   "type" => "textfield",
								   "label" => __('Excluded Categories ID', BUNCH_NAME ),
								   "name" => "exclude_cats",
								   "description" => __('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
								),
								$order,
								$orderby,
							),
						);
//Blog 2 Column
$options['bunch_blog_2_column']	=	array(
					'name' => esc_html__('Blog 2 Column', BUNCH_NAME),
					'base' => 'bunch_blog_2_column',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Blog 2 Column.', BUNCH_NAME),
					'params' => array(
								$number,
								array(
									"type" => "dropdown",
									"label" => __( 'Category', BUNCH_NAME),
									"name" => "cat",
									"options" =>  bunch_get_categories(array( 'taxonomy' => 'category'), true),
									"description" => __( 'Choose Category.', BUNCH_NAME)
								),
								$order,
								$orderby,
							),
						);
//Contact Us 2
$options['bunch_contact_us_2'] = array(
					'name' => esc_html__('Contact Us 2', BUNCH_NAME),
					'base' => 'bunch_contact_us_2',
					'class' => '',
					'category' => esc_html__('Contra', BUNCH_NAME),
					'icon' => 'fa-envelope' ,
					'description' => esc_html__('Show Contact Us 2.', BUNCH_NAME),
					'params' => array(
						esc_html__( 'Contact form', BUNCH_NAME ) => array(
							array(
								'type' => 'text',
								'label' => esc_html__( 'Background Title', BUNCH_NAME ),
								'name' => 'bg_title',
								'description' => esc_html__( 'Enter The Background Title.', BUNCH_NAME ),
							),
							$title,
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
								"name"			=>	"contact_form",
								"description"	=>	esc_html__('Enter section Contact Form.', BUNCH_NAME )
							),
						),
						esc_html__( 'Contact Info', BUNCH_NAME ) => array(
							array(
								'type' => 'group',
								'label' => esc_html__( 'Contact Info', BUNCH_NAME ),
								'name' => 'contact_info',
								'description' => esc_html__( 'Enter Contact Info', BUNCH_NAME ),
								'params' => array(
										array(
											"type"			=>	"text",
											"label"			=>	esc_html__('Title', BUNCH_NAME ),
											"name"			=>	"title1",
											"description"	=>	esc_html__('Enter title.', BUNCH_NAME )
										),
										array(
											"type"			=>	"textarea",
											"label"			=>	esc_html__('Text', BUNCH_NAME ),
											"name"			=>	"description",
											"description"	=>	esc_html__('Enter Description.', BUNCH_NAME )
										),
									),
								),
							),
							esc_html__( 'Google Map', BUNCH_NAME ) => array(
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Latitude', BUNCH_NAME ),
									"name"			=>	"lat",
									"description"	=>	esc_html__('Enter The Latitude.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Longitude', BUNCH_NAME ),
									"name"			=>	"long",
									"description"	=>	esc_html__('Enter The Longitude.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Map Zoom Value', BUNCH_NAME ),
									"name"			=>	"zoom",
									"description"	=>	esc_html__('Enter The Map Zoom Value.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Mark Title', BUNCH_NAME ),
									"name"			=>	"mark_title",
									"description"	=>	esc_html__('Enter The Mark Title.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Mark Address', BUNCH_NAME ),
									"name"			=>	"address",
									"description"	=>	esc_html__('Enter The Mark Address.', BUNCH_NAME )
								),
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Email', BUNCH_NAME ),
									"name"			=>	"email",
									"description"	=>	esc_html__('Enter The Email.', BUNCH_NAME )
								),
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Marker Image', BUNCH_NAME ),
									"name"			=>	"image",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Choose Marker image Url.', BUNCH_NAME )
								),
							),
						),
					);


return $options;