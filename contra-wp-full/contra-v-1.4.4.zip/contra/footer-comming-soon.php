<?php $options = get_option('contra'.'_theme_options');?>
<?php wp_footer(); ?>

</div>
<!--End pagewrapper-->

</body>
</html>